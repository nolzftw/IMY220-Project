# IMY220-Project
## Deliverables
Semester weight - 30%
### Deliverable 0
Weight - 3%<br/>
Due - 2024/08/05 07:30<br/>
Submitted - 2024/08/04 22:28
### Deliverable 1
Weight - 4.5%<br/>
Due - 2024/09/13 07:30<br/>
Submitted -
### Deliverable 2
Weight - 6%<br/>
Due - 2024/10/04 07:30<br/>
Submitted - 
### Deliverable 3
Weight - 16.5%<br/>
Due - 2024/11/03 23:59<br/>
Submitted - 

## How to run docker
docker build -t u21437883 .<br/>
docker run --name u21437883 -p 3005:3000 u21437883<br/>
docker stop u21437883<br/>
docker rm u21437883